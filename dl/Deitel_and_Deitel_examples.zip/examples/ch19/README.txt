Users of UNIX, Linux and Mac OS X should use the catalog_unix.txt file for the shopping cart application (Figs. 19.21-19.24). 

Be sure to rename the file as catalog.txt before running the application.